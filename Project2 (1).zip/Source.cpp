*****************************************************
5-3 Project Two
Name : Tristyn Tate
Date : 02/10/2025
*****************************************************
#include <iostream>
#include <iomanip>
using namespace std;

// Define printDetails exactly once with the required formatting.
// It prints the year, then two tab characters, then "$" and the year-end balance 
// (formatted to two decimals), two tab characters, then "$" and the interest earned (to two decimals).
void printDetails(int year, double yearEndBalance, double interestEarned) {
    cout << year << "\t\t$" << fixed << setprecision(2) << yearEndBalance
        << "\t\t$" << fixed << setprecision(2) << interestEarned << endl;
}

/**
 * Calculates and returns the end-of-year balance for a given number of years
 * without any additional monthly deposits.
 *
 * @param initialInvestment Dollar amount of the initial investment.
 * @param interestRate Annual interest rate in percent (e.g., 10 means 10%).
 * @param numberOfYears Number of years to calculate the balance for.
 * @return The final end-of-year balance.
 *
 * Compounding is done monthly (divide interestRate by 100 and then by 12).
 * The printDetails function is called once per year.
 */
double calculateBalanceWithoutMonthlyDeposit(double initialInvestment, double interestRate, int numberOfYears) {
    const int monthsInYear = 12;
    double balance = initialInvestment;

    for (int year = 1; year <= numberOfYears; year++) {
        double interestEarnedYear = 0.0;
        // Apply monthly compounding for the current year.
        for (int month = 1; month <= monthsInYear; month++) {
            double monthlyInterest = balance * (interestRate / 100.0 / monthsInYear);
            balance += monthlyInterest;
            interestEarnedYear += monthlyInterest;
        }
        // Call printDetails exactly once for this year.
        printDetails(year, balance, interestEarnedYear);
    }
    return balance;
}

/**
 * Calculates and returns the end-of-year balance for a given number of years
 * with an additional monthly deposit.
 *
 * @param initialInvestment Dollar amount of the initial investment.
 * @param monthlyDeposit Dollar amount added to the investment each month.
 * @param interestRate Annual interest rate in percent (e.g., 10 means 10%).
 * @param numberOfYears Number of years to calculate the balance for.
 * @return The final end-of-year balance.
 *
 * Compounding is done monthly (interestRate divided by 100 and then by 12).
 * This month's deposit does not earn interest until the next month.
 * The printDetails function is called once per year.
 */
double balanceWithMonthlyDeposit(double initialInvestment, double monthlyDeposit, double interestRate, int numberOfYears) {
    const int monthsInYear = 12;
    double balance = initialInvestment;

    for (int year = 1; year <= numberOfYears; year++) {
        double interestEarnedYear = 0.0;
        // Process each month of the current year.
        for (int month = 1; month <= monthsInYear; month++) {
            // Calculate monthly interest and update the balance.
            double monthlyInterest = balance * (interestRate / 100.0 / monthsInYear);
            balance += monthlyInterest;
            interestEarnedYear += monthlyInterest;
            // Then add the monthly deposit (this deposit will earn interest starting next month).
            balance += monthlyDeposit;
        }
        // Call printDetails exactly once for this year.
        printDetails(year, balance, interestEarnedYear);
    }
    return balance;
}

int main() {
    double initialInvestment, monthlyDeposit, interestRate;
    int numberOfYears;

    cout << "Enter initial investment amount: ";
    cin >> initialInvestment;
    cout << "Enter annual interest rate (in %): ";
    cin >> interestRate;
    cout << "Enter number of years: ";
    cin >> numberOfYears;
    cout << "Enter monthly deposit amount: ";
    cin >> monthlyDeposit;

    // For demonstration, call both functions.
    cout << "\n--- Calculating balance WITHOUT monthly deposits ---\n";
    double finalBalanceWithout = calculateBalanceWithoutMonthlyDeposit(initialInvestment, interestRate, numberOfYears);
    cout << "\nFinal balance without monthly deposits: $" << fixed << setprecision(2) << finalBalanceWithout << "\n" << endl;

    cout << "\n--- Calculating balance WITH monthly deposits ---\n";
    double finalBalanceWith = balanceWithMonthlyDeposit(initialInvestment, monthlyDeposit, interestRate, numberOfYears);
    cout << "\nFinal balance with monthly deposits: $" << fixed << setprecision(2) << finalBalanceWith << "\n" << endl;

    return 0;
}
